//
//  MRDRangeSliderView.h
//  RangeSlider
//
//  Created by Cathy on 2019/1/4.
//  Copyright © 2019 Cathy. All rights reserved.
//

#import "NPSOrderModuleDefinitions_internal.h"
#import "MRDRangeSliderDelegate.h"

typedef NS_ENUM(NSUInteger, MRDScaleDirection) {
    MRDScaleDirectionLeft = 0,
    MRDScaleDirectionRight,
};

typedef NS_ENUM(NSUInteger, MRDRangeSliderViewDirection) {
    MRDRangeSliderViewDirectionHorizontal = 0,
    MRDRangeSliderViewDirectionVertical,
};

@interface MRDRangeSliderView : UIControl <UIGestureRecognizerDelegate>

@property (nonatomic, strong) id<MRDRangeSliderDelegate> delegate;
@property (nonatomic, assign) CGFloat minValue;
@property (nonatomic, assign) CGFloat maxValue;
@property (nonatomic, assign) CGFloat selectedMinimum;
@property (nonatomic, assign) CGFloat selectedMaximum;
@property (nonatomic, assign) CGFloat minimumDistance;
@property (nonatomic, assign) MRDRangeSliderViewDirection sliderDirection;

@property (nonatomic, strong) UIImage *handleImage;
@property (nonatomic, assign) CGFloat handleDiameter;
@property (nonatomic, assign) CGFloat barSidePadding;
@property (nonatomic, strong) UIColor *handleColor;
@property (nonatomic, strong) UIColor *tintColorBetweenHandles;
@property (nonatomic, assign) CGFloat shadowRadius;
@property (nonatomic, strong) UIColor *shadowColor;

@property (nonatomic, assign) CGFloat lineWidth;
@property (nonatomic, strong) UIColor *lineBorderColor;
@property (nonatomic, assign) CGFloat lineBorderWidth;

@property (nonatomic, assign) CGFloat scaleHeight;
@property (nonatomic, assign) MRDScaleDirection scaleDirection;

@end

