//
//  MRDRangeSliderDelegate.h
//  RangeSlider
//
//  Created by Cathy on 2019/1/4.
//  Copyright © 2019 Cathy. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MRDRangeSliderView;

@protocol MRDRangeSliderDelegate <NSObject>

@optional

/**
 * Called when the RangeSlider values are changed
 */
-(void)didChangeRangeSlider:(MRDRangeSliderView *)sender
       selectedMinimumValue:(CGFloat)selectedMinimum
               maximumValue:(CGFloat)selectedMaximum;

/**
 * Called when the user has finished interacting with the RangeSlider
 */
- (void)didEndTouchesInRangeSlider:(MRDRangeSliderView *)sender
              selectedMinimumValue:(CGFloat)selectedMinimum
                      maximumValue:(CGFloat)selectedMaximum;

/**
 * Called when the user has started interacting with the RangeSlider
 */
- (void)didStartTouchesInRangeSlider:(MRDRangeSliderView *)sender;

@end
