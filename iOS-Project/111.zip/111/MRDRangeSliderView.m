//
//  MRDRangeSliderView.m
//  RangeSlider
//
//  Created by Cathy on 2019/1/4.
//  Copyright © 2019 Cathy. All rights reserved.
//

#import "MRDRangeSliderView.h"

const int HANDLE_TOUCH_AREA_EXPANSION = -30;

@interface MRDRangeSliderView ()

@property (nonatomic, strong) CALayer *sliderLine;
@property (nonatomic, strong) CALayer *sliderLineBetweenHandles;

@property (nonatomic, strong) CALayer *leftHandle;
@property (nonatomic, assign) BOOL leftHandleSelected;
@property (nonatomic, strong) CALayer *rightHandle;
@property (nonatomic, assign) BOOL rightHandleSelected;

@property (nonatomic, strong) CAShapeLayer *scaleLine;
@property (nonatomic, strong) CAShapeLayer *scaleSelectedLine;
@property (nonatomic, assign) CGFloat minScale;

@end

@implementation MRDRangeSliderView

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupDefault];
        
    }
    return self;
}

- (void)setupDefault {
    //defaults:
    _minValue = _selectedMinimum = 0;
    _maxValue = _selectedMaximum = 7;
    _minimumDistance = 1;
    _sliderDirection = MRDRangeSliderViewDirectionVertical;
    
    _handleDiameter = 52;
    _barSidePadding = 16.0;
    _lineWidth = 2.0;
    
    _scaleHeight = 4.0;
    _scaleDirection = MRDScaleDirectionLeft;
    
    //draw the slider line
    self.sliderLine = [CALayer layer];
    self.sliderLine.backgroundColor = self.tintColor.CGColor;
    self.sliderLine.borderColor = self.tintColor.CGColor;
    [self.layer addSublayer:self.sliderLine];
    
    //draw the track distline
    self.sliderLineBetweenHandles = [CALayer layer];
    self.sliderLineBetweenHandles.backgroundColor = self.tintColor.CGColor;
    [self.layer addSublayer:self.sliderLineBetweenHandles];
    
    //draw the minimum slider handle
    self.leftHandle = [CALayer layer];
    self.leftHandle.cornerRadius = self.handleDiameter / 2;
    self.leftHandle.backgroundColor = self.handleColor.CGColor;
    [self.layer addSublayer:self.leftHandle];
    
    //draw the maximum slider handle
    self.rightHandle = [CALayer layer];
    self.rightHandle.cornerRadius = self.handleDiameter / 2;
    self.rightHandle.backgroundColor = self.handleColor.CGColor;
    [self.layer addSublayer:self.rightHandle];
    
    // draw the scale line
    self.scaleLine = [[CAShapeLayer alloc] init];
    self.scaleLine.lineWidth = self.lineWidth;
    self.scaleLine.strokeColor = self.tintColor.CGColor;
    [self.sliderLine addSublayer:self.scaleLine];
    
    self.scaleSelectedLine = [[CAShapeLayer alloc] init];
    self.scaleSelectedLine.lineWidth = self.lineWidth;
    self.scaleSelectedLine.strokeColor = self.tintColor.CGColor;
    [self.sliderLine addSublayer:self.scaleSelectedLine];
    
    self.leftHandle.frame = CGRectMake(0, 0, self.handleDiameter, self.handleDiameter);
    self.rightHandle.frame = CGRectMake(0, 0, self.handleDiameter, self.handleDiameter);
    
    [self refresh];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    //positioning for the slider line
    CGFloat barSidePadding = self.barSidePadding;
    CGRect currentFrame = self.frame;
    CGRect sliderFrame = CGRectZero;
    switch (self.sliderDirection) {
        case MRDRangeSliderViewDirectionHorizontal:
        {
            CGFloat yMiddle = currentFrame.size.height / 2.0;
            CGPoint lineLeftSide = CGPointMake(barSidePadding, yMiddle);
            CGPoint lineRightSide = CGPointMake(currentFrame.size.width - barSidePadding, yMiddle);
            sliderFrame = CGRectMake(lineLeftSide.x, lineLeftSide.y, lineRightSide.x - lineLeftSide.x, self.lineWidth);
        }
            break;
        case MRDRangeSliderViewDirectionVertical:
        {
            CGFloat xMiddle = currentFrame.size.width / 2.0;
            CGPoint lineTopSide = CGPointMake(xMiddle, barSidePadding);
            CGPoint lineBoottomSide = CGPointMake(xMiddle, currentFrame.size.height - barSidePadding);
            sliderFrame = CGRectMake(lineTopSide.x, lineTopSide.y,self.lineWidth,  lineBoottomSide.y-lineTopSide.y);
        }
            break;
        default:
            break;
    }
    
    self.sliderLine.frame = sliderFrame;
    self.sliderLine.cornerRadius = self.lineWidth / 2.0;
    self.sliderLineBetweenHandles.cornerRadius = self.lineWidth / 2.0;
    
    self.minScale = CGRectGetHeight(sliderFrame) / (self.maxValue - self.minValue);
    
    [self updateHandlePositions];
    [self drawSegment:self.sliderLine];
    [self updateSegmentColor];
}

- (void)drawSegment: (CALayer *)layer {
    UIBezierPath *path = [UIBezierPath bezierPath];
    NSUInteger step = (NSUInteger)(self.maxValue - self.minValue);
    
    CGFloat distance = self.scaleDirection == MRDScaleDirectionRight ? self.scaleHeight : -self.scaleHeight;
    
    switch (self.sliderDirection) {
        case MRDRangeSliderViewDirectionHorizontal:
        {
            NSUInteger minScale = CGRectGetWidth(self.sliderLine.frame) / step;
            for (NSUInteger i = self.minValue; i <= step; i ++) {
                CGFloat x = i * minScale;
                [path moveToPoint:CGPointMake(x, self.lineWidth / 2)];
                [path addLineToPoint:CGPointMake(x, distance)];
            }
        }
            break;
        case MRDRangeSliderViewDirectionVertical:
        {
            NSUInteger minScale = CGRectGetHeight(self.sliderLine.frame) / step;
            for (NSUInteger i = self.minValue; i <= step; i ++) {
                CGFloat y = i * minScale;
                [path moveToPoint:CGPointMake(self.lineWidth / 2, y)];
                [path addLineToPoint:CGPointMake(distance, y)];
            }
        }
            break;
        default:
            break;
    }
    self.scaleLine.strokeColor = self.tintColor.CGColor;
    self.scaleLine.path = path.CGPath;
}

- (void)updateSegmentColor {
    UIBezierPath *path = [UIBezierPath bezierPath];
    NSUInteger step = (NSUInteger)(self.maxValue - self.minValue);
    
    CGFloat distance = self.scaleDirection == MRDScaleDirectionRight ? self.scaleHeight : -self.scaleHeight;
    if (self.sliderDirection == MRDRangeSliderViewDirectionHorizontal) {
        for (NSUInteger i = self.minValue; i <= step; i ++) {
            if (i >= self.selectedMinimum && i <= self.selectedMaximum) {
                CGFloat x = i * self.minScale;
                [path moveToPoint:CGPointMake(x, self.lineWidth / 2)];
                [path addLineToPoint:CGPointMake(x, distance)];
            }
        }
    } else {
        for (NSUInteger i = self.minValue; i <= step; i ++) {
            if (i >= self.selectedMinimum && i <= self.selectedMaximum) {
                CGFloat y = i * self.minScale;
                [path moveToPoint:CGPointMake(self.lineWidth / 2, y)];
                [path addLineToPoint:CGPointMake(distance, y)];
            }
        }
    }
    
    self.scaleSelectedLine.strokeColor = self.tintColorBetweenHandles.CGColor;
    self.scaleSelectedLine.path = path.CGPath;
}

- (CGFloat)getPercentageAlongLineForValue:(CGFloat) value {
    if (self.minValue == self.maxValue) {
        return 0;
    }
    
    CGFloat maxMinDif = self.maxValue - self.minValue;
    CGFloat valueSubtracted = value - self.minValue;
    return valueSubtracted / maxMinDif;
}

- (CGFloat)getYPositionAlongLineForValue:(CGFloat) value {
    CGFloat percentage = [self getPercentageAlongLineForValue:value];
    
    if (self.sliderDirection == MRDRangeSliderViewDirectionHorizontal) {
        CGFloat maxMinDif = CGRectGetMaxX(self.sliderLine.frame) - CGRectGetMinX(self.sliderLine.frame);
        CGFloat offset = percentage * maxMinDif;
        return CGRectGetMinX(self.sliderLine.frame) + offset;
        
    } else {
        
        CGFloat maxMinDif = CGRectGetMaxY(self.sliderLine.frame) - CGRectGetMinY(self.sliderLine.frame);
        CGFloat offset = percentage * maxMinDif;
        return CGRectGetMinY(self.sliderLine.frame) + offset;
    }
}

#pragma mark - Set Positions
- (void)updateHandlePositions {
    if (self.sliderDirection == MRDRangeSliderViewDirectionHorizontal) {
        CGPoint leftHandleCenter = CGPointMake([self getYPositionAlongLineForValue:self.selectedMinimum],
                                               CGRectGetMidY(self.sliderLine.frame));
        self.leftHandle.position = leftHandleCenter;
        
        CGPoint rightHandleCenter = CGPointMake([self getYPositionAlongLineForValue:self.selectedMaximum],
                                                CGRectGetMidY(self.sliderLine.frame));
        self.rightHandle.position= rightHandleCenter;
        
        //positioning for the dist slider line
        self.sliderLineBetweenHandles.frame = CGRectMake(self.leftHandle.position.x,
                                                         self.sliderLine.frame.origin.y,
                                                         self.rightHandle.position.x - self.leftHandle.position.x, self.lineWidth);
    } else {
        CGPoint topHandleCenter = CGPointMake(CGRectGetMidX(self.sliderLine.frame),
                                              [self getYPositionAlongLineForValue:self.selectedMinimum]);
        self.leftHandle.position = topHandleCenter;
        
        CGPoint bottomHandleCenter = CGPointMake(CGRectGetMidX(self.sliderLine.frame),
                                                 [self getYPositionAlongLineForValue:self.selectedMaximum]);
        self.rightHandle.position= bottomHandleCenter;
        
        //positioning for the dist slider line
        self.sliderLineBetweenHandles.frame = CGRectMake(self.sliderLine.frame.origin.x,
                                                         self.leftHandle.position.y,
                                                         self.lineWidth,
                                                         self.rightHandle.position.y - self.leftHandle.position.y);
    }
}

#pragma mark - Touch Tracking
- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    CGPoint gesturePressLocation = [touch locationInView:self];
    
    if (CGRectContainsPoint(CGRectInset(self.leftHandle.frame,
                                        HANDLE_TOUCH_AREA_EXPANSION,
                                        HANDLE_TOUCH_AREA_EXPANSION), gesturePressLocation) ||
        CGRectContainsPoint(CGRectInset(self.rightHandle.frame,
                                        HANDLE_TOUCH_AREA_EXPANSION,
                                        HANDLE_TOUCH_AREA_EXPANSION), gesturePressLocation)) {
        
        CGFloat distanceFromLeftHandle = [self distanceBetweenPoint:gesturePressLocation
                                                           andPoint:[self getCentreOfRect:self.leftHandle.frame]];
        CGFloat distanceFromRightHandle =[self distanceBetweenPoint:gesturePressLocation
                                                           andPoint:[self getCentreOfRect:self.rightHandle.frame]];
        
        if (distanceFromLeftHandle < distanceFromRightHandle){
            self.leftHandleSelected = YES;
        } else {
            self.rightHandleSelected = YES;
        }
        
        if ([self.delegate respondsToSelector:@selector(didStartTouchesInRangeSlider:)]){
            [self.delegate didStartTouchesInRangeSlider:self];
        }
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)continueTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    CGFloat percentage = 0.0f;
    CGFloat max = 0.0;
    
    CGPoint location = [touch locationInView:self];
    
    if (self.sliderDirection == MRDRangeSliderViewDirectionHorizontal) {
        CGFloat currentX = location.x - CGRectGetMinX(self.sliderLine.frame);
        max = CGRectGetMaxX(self.sliderLine.frame) - CGRectGetMinX(self.sliderLine.frame);
        percentage = currentX / max;
    } else {
        CGFloat currentY = location.y - CGRectGetMinY(self.sliderLine.frame);
        max = CGRectGetMaxY(self.sliderLine.frame) - CGRectGetMinY(self.sliderLine.frame);
        percentage = currentY / max;
    }
    
    CGFloat selectedValue = (percentage * (self.maxValue - self.minValue) + self.minValue);
    if (self.leftHandleSelected) {
        if (selectedValue < self.selectedMaximum - self.minimumDistance) {
            self.selectedMinimum = selectedValue;
        } else {
            self.selectedMinimum = self.selectedMaximum - self.minimumDistance;
        }
        
    } else if (self.rightHandleSelected) {
        if (selectedValue > self.selectedMinimum + self.minimumDistance) {
            self.selectedMaximum = selectedValue;
        } else {
            self.selectedMaximum = self.selectedMinimum + self.minimumDistance;
        }
    }
    return YES;
}

- (void)endTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    CGPoint location = [touch locationInView:self];
    CGFloat current = 0.0;
    CGFloat max = 0.0;
    if (self.sliderDirection == MRDRangeSliderViewDirectionHorizontal) {
        current = location.x - CGRectGetMinX(self.sliderLine.frame);
        max = CGRectGetMaxX(self.sliderLine.frame) - CGRectGetMinX(self.sliderLine.frame);
    } else {
        current = location.y - CGRectGetMinY(self.sliderLine.frame);
        max = CGRectGetMaxY(self.sliderLine.frame) - CGRectGetMinY(self.sliderLine.frame);
    }
    
    
    CGFloat selectedValue = ((current / max) * (self.maxValue - self.minValue) + self.minValue);
    int finalValue = roundf(selectedValue);
    
    if (self.leftHandleSelected) {
        if (finalValue < self.selectedMaximum) {
            self.selectedMinimum = finalValue;
        } else {
            self.selectedMinimum = self.selectedMaximum - self.minimumDistance;
        }
        self.leftHandleSelected = NO;
    } else {
        if (finalValue > self.selectedMinimum) {
            self.selectedMaximum = finalValue;
        } else {
            self.selectedMaximum = self.selectedMinimum + self.minimumDistance;
        }
        self.rightHandleSelected = NO;
    }
    [self updateSegmentColor];
    
    if ([self.delegate respondsToSelector:@selector(didEndTouchesInRangeSlider:selectedMinimumValue:maximumValue:)]) {
        [self.delegate didEndTouchesInRangeSlider:self
                             selectedMinimumValue:self.selectedMinimum
                                     maximumValue:self.selectedMaximum];
    }
}

- (void)refresh {
    if (self.selectedMinimum <= self.minValue) {
        _selectedMinimum = self.minValue;
    }
    if (self.selectedMaximum >= self.maxValue) {
        _selectedMaximum = self.maxValue;
    }
    
    [CATransaction begin];
    [CATransaction setDisableActions:YES] ;
    [self updateHandlePositions];
    [CATransaction commit];
    
    //update the delegate
    if ([self.delegate respondsToSelector:@selector(didChangeRangeSlider:selectedMinimumValue:maximumValue:)] &&
        (self.leftHandleSelected || self.rightHandleSelected)){
        [self.delegate didChangeRangeSlider:self
                       selectedMinimumValue:self.selectedMinimum
                               maximumValue:self.selectedMaximum];
    }
    [self sendActionsForControlEvents:UIControlEventValueChanged];
}

#pragma mark - Calculating nearest handle to point
- (CGFloat)distanceBetweenPoint:(CGPoint)point1 andPoint:(CGPoint)point2 {
    CGFloat xDist = (point2.x - point1.x);
    CGFloat yDist = (point2.y - point1.y);
    return sqrt((xDist * xDist) + (yDist * yDist));
}

- (CGPoint)getCentreOfRect:(CGRect)rect {
    return CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
}

- (void)setMinValue:(CGFloat)minValue {
    _minValue = minValue;
    [self refresh];
}

- (void)setMaxValue:(CGFloat)maxValue {
    _maxValue = maxValue;
    [self refresh];
}

- (void)setSelectedMinimum:(CGFloat)selectedMinimum {
    if (selectedMinimum < self.minValue) {
        selectedMinimum = self.minValue;
    }
    _selectedMinimum = selectedMinimum;
    [self refresh];
}

- (void)setSelectedMaximum:(CGFloat)selectedMaximum {
    if (selectedMaximum > self.maxValue) {
        selectedMaximum = self.maxValue;
    }
    _selectedMaximum = selectedMaximum;
    [self refresh];
}

-(void)setHandleImage:(UIImage *)handleImage{
    _handleImage = handleImage;
    
    CGRect startFrame = CGRectMake(0.0, 0.0, 52, 52);
    self.leftHandle.contents = (id)handleImage.CGImage;
    self.leftHandle.frame = startFrame;
    
    self.rightHandle.contents = (id)handleImage.CGImage;
    self.rightHandle.frame = startFrame;
    
    //Force layer background to transparant
    self.leftHandle.backgroundColor = [UIColor clearColor].CGColor;
    self.rightHandle.backgroundColor = [UIColor clearColor].CGColor;
}

-(void)setHandleColor:(UIColor *)handleColor{
    self.leftHandle.backgroundColor = handleColor.CGColor;
    self.rightHandle.backgroundColor = handleColor.CGColor;
}

-(void)setHandleDiameter:(CGFloat)handleDiameter{
    _handleDiameter = handleDiameter;
    
    self.leftHandle.cornerRadius = self.handleDiameter / 2;
    self.rightHandle.cornerRadius = self.handleDiameter / 2;
    
    self.leftHandle.frame = CGRectMake(0, 0, self.handleDiameter, self.handleDiameter);
    self.rightHandle.frame = CGRectMake(0, 0, self.handleDiameter, self.handleDiameter);
    
}

- (void)setShadowRadius:(CGFloat)shadowRadius {
    _shadowRadius = shadowRadius;
    
    self.leftHandle.shadowRadius = self.shadowRadius;
    self.rightHandle.shadowRadius = shadowRadius;
}

- (void)setShadowColor:(UIColor *)shadowColor {
    _shadowColor = shadowColor;
    self.leftHandle.shadowColor = shadowColor.CGColor;
    self.leftHandle.shadowOpacity = 0.2;
    self.leftHandle.shadowOffset = CGSizeMake(0, 0);
    
    self.rightHandle.shadowColor = shadowColor.CGColor;
    self.rightHandle.shadowOpacity = 0.2;
    self.rightHandle.shadowOffset = CGSizeMake(0, 0);
}

- (void)tintColorDidChange {
    CGColorRef color = self.tintColor.CGColor;
    
    [CATransaction begin];
    [CATransaction setAnimationDuration:0.5];
    [CATransaction setAnimationTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    self.sliderLine.backgroundColor = color;
    [CATransaction commit];
}

-(void)setTintColorBetweenHandles:(UIColor *)tintColorBetweenHandles {
    _tintColorBetweenHandles = tintColorBetweenHandles;
    self.sliderLineBetweenHandles.backgroundColor = tintColorBetweenHandles.CGColor;
}

- (void)setLineWidth:(CGFloat)lineWidth {
    _lineWidth = lineWidth;
    [self setNeedsLayout];
}

-(void)setLineBorderColor:(UIColor *)lineBorderColor {
    _lineBorderColor = lineBorderColor;
    self.sliderLine.borderColor = lineBorderColor.CGColor;
}

-(void)setLineBorderWidth:(CGFloat)lineBorderWidth {
    _lineBorderWidth = lineBorderWidth;
    self.sliderLine.borderWidth = lineBorderWidth;
}

@end
